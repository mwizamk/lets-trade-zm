# Let's Trade ZM — v0.4.0 Design Prototype

This release is the fresh Phase 1 landing-page design.

## Phase 1 scope

- Clean, organized landing page
- Mobile-first responsive design
- Multiple service selection
- Category filtering
- Live selection count
- Live total calculation
- Sticky selection/continue bar
- Simple "How it works" section
- Support section

## Intentionally NOT included yet

- Firebase / Firestore
- Firebase Authentication
- Real PriceList loading
- Customer database
- Signup workflow
- Payment processing
- Admin portal
- Automation

Those will be added in later phases after the design is approved.

## Files

```text
lets-tradezm-plugmk/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
└── README.md
```

## Prototype services

The prices in `js/app.js` are temporary design data only. They will be replaced with Firestore PriceList data in the backend phase.
